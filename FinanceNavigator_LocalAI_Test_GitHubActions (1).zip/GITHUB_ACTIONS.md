# Сборка APK через GitHub Actions — только с телефона

GitHub Actions собирает Android APK на стороне GitHub. Android-проект использует Gradle, а workflow запускает `assembleDebug` и сохраняет готовый APK как artifact.

## Один раз

1. Открой GitHub в браузере и войди в свой аккаунт.
2. Создай новый **публичный** репозиторий, например `FinanceNavigator`.
3. Загрузи содержимое этого проекта в репозиторий (не сам ZIP как один файл): в корне должны лежать `build.gradle`, `settings.gradle`, папка `app` и `.github`.
4. Сделай Commit changes в ветку `main`.

## Получение APK

После commit GitHub автоматически запустит:

**Actions → Build Android APK → Build debug APK**

После завершения открой запуск workflow и внизу страницы найди **Artifacts → FinanceNavigator-debug-apk**. Скачай архив и извлеки `app-debug.apk`.

Можно также запустить вручную через **Actions → Build Android APK → Run workflow**.

## Важно

Это debug APK для установки и тестирования. Для публикации в Google Play позже понадобится отдельная release-подпись и AAB/APK. Не добавляй ключ подписи в репозиторий.
