
package com.example.financenavigator.data;

import java.util.*;

public class FinanceEngine {
    public static class Result {
        public double safeToSpend, dailyLimit, projectedEnd, reserve;
        public int days;
        public String status, message;
    }
    public static Result calculate(double balance, double reserve, int days,
                                   double fixedDaily, double variableDaily) {
        Result r = new Result();
        r.reserve = Math.max(0, reserve);
        r.days = Math.max(1, days);
        r.dailyLimit = Math.max(0, balance - r.reserve) / r.days;
        double forecast = (fixedDaily + variableDaily) * r.days;
        r.projectedEnd = balance - r.reserve - forecast;
        r.safeToSpend = Math.max(0, balance - r.reserve - forecast);
        if (r.projectedEnd < 0) {
            r.status="STOP";
            r.message="При текущем темпе расходов денег не хватит до следующего пополнения.";
        } else if (r.safeToSpend < r.dailyLimit) {
            r.status="CAUTION";
            r.message="Деньги есть, но лучше придерживаться установленного лимита.";
        } else {
            r.status="OK";
            r.message="Расход укладывается в прогноз.";
        }
        return r;
    }
}
