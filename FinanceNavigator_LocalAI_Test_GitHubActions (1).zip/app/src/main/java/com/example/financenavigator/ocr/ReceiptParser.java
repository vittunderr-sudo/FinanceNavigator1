
package com.example.financenavigator.ocr;

import java.util.*;
import java.util.regex.*;

public class ReceiptParser {
    public static class Line { public String name; public double price; Line(String n,double p){name=n;price=p;} }
    // Generic receipt parser; store-specific formats can be added later.
    public static List<Line> parse(String text) {
        List<Line> out=new ArrayList<>();
        if(text==null) return out;
        Pattern p=Pattern.compile("(.+?)\\s+(\\d+[\\.,]\\d{2})\\s*(?:₽|руб)?$");
        for(String raw:text.split("\\n")) {
            String s=raw.trim().replace(',','.');
            Matcher m=p.matcher(s);
            if(m.find()){
                try { out.add(new Line(m.group(1).trim(),Double.parseDouble(m.group(2)))); }
                catch(Exception ignored){}
            }
        }
        return out;
    }
}
