
package com.example.financenavigator.store;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public interface StoreProvider {
    String id();
    String title();
    String packageName();
    String webUrl();

    default boolean open(Context c) {
        Intent i=c.getPackageManager().getLaunchIntentForPackage(packageName());
        if(i!=null){ c.startActivity(i); return true; }
        try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(webUrl()))); return false; }
        catch(Exception e){ return false; }
    }
}
