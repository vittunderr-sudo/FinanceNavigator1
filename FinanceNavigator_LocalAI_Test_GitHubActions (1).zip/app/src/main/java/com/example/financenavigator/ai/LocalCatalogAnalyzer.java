
package com.example.financenavigator.ai;

import com.example.financenavigator.catalog.PriceObservation;
import java.util.*;
import java.util.regex.*;

public class LocalCatalogAnalyzer {
    // Extracts common price patterns from text made available to the app.
    // It does not bypass login, DRM, anti-bot systems, or another app's private data.
    public static List<PriceObservation> analyze(String storeId, String storeName,
                                                 String text, String source) {
        List<PriceObservation> result=new ArrayList<>();
        if(text==null) return result;
        Pattern p=Pattern.compile("(?im)([^\\n]{2,80}?)\\s+(\\d+[\\s]?\\d{0,3}[\\.,]\\d{2})\\s*(?:₽|руб)?");
        Matcher m=p.matcher(text);
        while(m.find()){
            String name=m.group(1).trim().replaceAll("\\s+"," ");
            String priceText=m.group(2).replace(" ","").replace(",",".");
            try{
                double price=Double.parseDouble(priceText);
                if(price>0 && price<100000)
                    result.add(new PriceObservation(storeId,storeName,name,price,"","",String.valueOf(System.currentTimeMillis()),source));
            }catch(Exception ignored){}
        }
        return result;
    }
}
