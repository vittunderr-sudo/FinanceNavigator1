package com.example.financenavigator;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import androidx.core.app.ActivityCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.example.financenavigator.location.LocationHelper;
import com.example.financenavigator.ai.LocalAdvisor;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new StoreBridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        LocationHelper.request(this);
    }
    class StoreBridge {
        @JavascriptInterface public void openStore(String id){
            for(com.example.financenavigator.store.StoreProvider store :
                com.example.financenavigator.store.StoreRegistry.all()){
                if(store.id().equals(id)){
                    store.open(MainActivity.this);
                    return;
                }
            }
        }

        @JavascriptInterface public void requestLocation(){ LocationHelper.request(MainActivity.this); }

        @JavascriptInterface public String localAdvice(double safe,double price,int days,String item){
            return LocalAdvisor.advise(safe,price,days,item);
        }

        @JavascriptInterface public void scanReceipt(){
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            try{ startActivityForResult(i,900); }
            catch(Exception e){ Toast.makeText(MainActivity.this,"Камера недоступна",Toast.LENGTH_SHORT).show(); }
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==900 && resultCode==RESULT_OK && data!=null && data.getExtras()!=null){
            Bitmap b=(Bitmap)data.getExtras().get("data");
            if(b==null)return;
            InputImage image=InputImage.fromBitmap(b,0);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener(r->{
                    String text=r.getText().replace("\\","\\\\").replace("'","\\'").replace("\n","\\\\n");
                    web.evaluateJavascript("window.receiptOCR && window.receiptOCR('"+text+"')",null);
                })
                .addOnFailureListener(e->Toast.makeText(MainActivity.this,"Не удалось распознать чек",Toast.LENGTH_SHORT).show());
        }
    }
    @Override public void onBackPressed(){
        if(web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}