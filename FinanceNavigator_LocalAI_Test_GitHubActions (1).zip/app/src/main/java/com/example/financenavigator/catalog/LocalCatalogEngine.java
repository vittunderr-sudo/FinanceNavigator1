
package com.example.financenavigator.catalog;

import java.util.*;

public class LocalCatalogEngine {
    private final List<PriceObservation> observations = new ArrayList<>();

    public void learn(PriceObservation o) {
        if (o == null || o.product == null || o.product.trim().isEmpty() || o.price < 0) return;
        observations.add(o);
    }

    public List<PriceObservation> search(String query) {
        String q=(query==null?"":query.toLowerCase().trim());
        List<PriceObservation> out=new ArrayList<>();
        for(PriceObservation o: observations)
            if(o.normalizedProduct.contains(q) || q.contains(o.normalizedProduct)) out.add(o);
        out.sort(Comparator.comparingDouble(x -> x.price));
        return out;
    }

    public double minPrice(String query) {
        List<PriceObservation> x=search(query);
        return x.isEmpty() ? -1 : x.get(0).price;
    }

    public int size(){ return observations.size(); }
}
