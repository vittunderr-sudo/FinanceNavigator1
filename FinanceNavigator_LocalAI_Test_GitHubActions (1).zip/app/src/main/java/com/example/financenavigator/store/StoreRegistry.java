
package com.example.financenavigator.store;

import java.util.*;

public class StoreRegistry {
    public static List<StoreProvider> all() {
        return Arrays.asList(
            new Basic("magnit","Магнит","ru.tander.magnit","https://magnit.ru/"),
            new Basic("pyaterochka","Пятёрочка","ru.pyaterochka","https://5ka.ru/"),
            new Basic("dixy","ДИКСИ","ru.dixy","https://dixy.ru/"),
            new Basic("yango","Яндекс Go","ru.yandex.yango","https://go.yandex.ru/")
        );
    }
    static class Basic implements StoreProvider {
        final String i,t,p,u;
        Basic(String i,String t,String p,String u){this.i=i;this.t=t;this.p=p;this.u=u;}
        public String id(){return i;} public String title(){return t;}
        public String packageName(){return p;} public String webUrl(){return u;}
    }
}
