
package com.example.financenavigator.ai;

import java.util.*;

public class LocalAdvisor {
    // Lightweight on-device advisor. No network and no account are required.
    // It deliberately uses deterministic rules for money calculations.
    public static String advise(double safe, double price, int daysLeft, String item) {
        if (price <= 0) return "Укажи цену, чтобы проверить покупку.";
        if (safe < price) return "Лучше не покупать: цена выше безопасного остатка.";
        double after=safe-price;
        if (daysLeft <= 0) return "Срок пополнения уже наступил — проверь баланс.";
        double perDay=after/daysLeft;
        if (perDay < price*0.05) return "Покупка возможна, но почти съест свободный запас.";
        return "Покупка укладывается в текущий прогноз. После неё останется примерно " +
                Math.round(after) + " ₽.";
    }
    public static List<String> rankRecipes(List<String> names) {
        return new ArrayList<>(names);
    }
}
