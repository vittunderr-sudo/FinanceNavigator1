
package com.example.financenavigator.catalog;

public class PriceObservation {
    public String storeId, storeName, product, normalizedProduct;
    public double price;
    public String unit, promo, observedAt, source;
    public PriceObservation(String storeId,String storeName,String product,double price,
                            String unit,String promo,String observedAt,String source){
        this.storeId=storeId; this.storeName=storeName; this.product=product;
        this.normalizedProduct=product==null?"":product.toLowerCase().trim();
        this.price=price; this.unit=unit; this.promo=promo;
        this.observedAt=observedAt; this.source=source;
    }
}
